#!/bin/bash
# Omnic Services - Restore Defaults (Linux Example)
# Run as root!

echo "Restoring system defaults..."

# Restore default watcher limits
sysctl -w fs.inotify.max_user_watches=8192
sysctl -w fs.inotify.max_user_instances=128

# Restore default network settings
sysctl -w net.core.rmem_max=212992
sysctl -w net.core.wmem_max=212992
sysctl -w net.ipv4.tcp_rmem="4096 87380 6291456"
sysctl -w net.ipv4.tcp_wmem="4096 16384 4194304"
sysctl -w net.ipv4.tcp_congestion_control=cubic

# Remove tweaks from /etc/sysctl.conf
sed -i '/fs.inotify.max_user_watches/d' /etc/sysctl.conf
sed -i '/fs.inotify.max_user_instances/d' /etc/sysctl.conf
sed -i '/net.core.rmem_max/d' /etc/sysctl.conf
sed -i '/net.core.wmem_max/d' /etc/sysctl.conf
sed -i '/net.ipv4.tcp_rmem/d' /etc/sysctl.conf
sed -i '/net.ipv4.tcp_wmem/d' /etc/sysctl.conf
sed -i '/net.ipv4.tcp_congestion_control/d' /etc/sysctl.conf

echo "Defaults restored! You may need to reboot."