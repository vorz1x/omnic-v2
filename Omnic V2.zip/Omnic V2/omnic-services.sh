#!/bin/bash
# Omnic Services - Terminal Tweaks Utility (Linux Example)
# Run as root!

function fps_boost() {
    echo "Applying FPS Boost tweaks..."
    sysctl -w vm.swappiness=10
    sysctl -w vm.dirty_ratio=10
    sysctl -w vm.dirty_background_ratio=5
    echo "Tweaks applied: Lowered swappiness and improved memory handling."
}

function aim_assist() {
    echo "Applying Aim Assist tweaks (mouse acceleration off)..."
    xinput --set-prop "pointer:Logitech Gaming Mouse" "libinput Accel Profile Enabled" 0, 1 2>/dev/null
    gsettings set org.gnome.desktop.peripherals.mouse accel-profile 'flat' 2>/dev/null
    echo "Mouse acceleration disabled (where supported)."
}

function ping_optimization() {
    echo "Applying Ping Optimization tweaks..."
    sysctl -w net.ipv4.tcp_timestamps=0
    sysctl -w net.ipv4.tcp_sack=1
    sysctl -w net.ipv4.tcp_window_scaling=1
    sysctl -w net.ipv4.tcp_no_metrics_save=1
    echo "Ping/network tweaks applied."
}

function restore_defaults() {
    echo "Restoring defaults..."
    sysctl -w vm.swappiness=60
    sysctl -w vm.dirty_ratio=20
    sysctl -w vm.dirty_background_ratio=10
    # Attempt to enable mouse acceleration (may not be supported everywhere)
    gsettings set org.gnome.desktop.peripherals.mouse accel-profile 'adaptive' 2>/dev/null
    echo "Defaults restored."
}

while true; do
    echo "===== Omnic Services: Terminal Tweaks ====="
    echo "Choose an option:"
    echo "1) FPS Boost"
    echo "2) Aim Assist (disable mouse acceleration)"
    echo "3) Ping Optimization"
    echo "4) Restore Defaults"
    echo "5) Exit"
    read -p "Enter your choice [1-5]: " choice

    case $choice in
        1) fps_boost ;;
        2) aim_assist ;;
        3) ping_optimization ;;
        4) restore_defaults ;;
        5) echo "Goodbye!"; exit 0 ;;
        *) echo "Invalid choice, try again." ;;
    esac
    echo ""
    read -p "Press enter to return to the menu..."
    clear
done