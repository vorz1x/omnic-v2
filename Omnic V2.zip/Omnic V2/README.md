# Omnic Services - Terminal Tweaks Utility

A simple bash-based utility for easily applying common gaming/system tweaks from the terminal.

## Usage

**Run as root:**
```bash
sudo bash omnic-services.sh
```

You'll see a menu with options like:
- FPS Boost
- Aim Assist (disables mouse acceleration)
- Ping Optimization
- Restore Defaults

Select the number for the tweak you want to apply!

## Notes

- Some tweaks (like mouse acceleration) require a compatible desktop environment.
- Tweaks are applied temporarily (lost after reboot unless added to sysctl.conf).
- Always review the script and test on your system.